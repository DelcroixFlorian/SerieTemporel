insert into utilisateur values (1, 'jean', null, 'monpotdepasse', null);
insert into utilisateur values (2, 'marc', null, 'monbeaupotdepasse', null);