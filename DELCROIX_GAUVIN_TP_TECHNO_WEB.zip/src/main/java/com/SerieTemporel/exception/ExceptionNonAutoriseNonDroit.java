package com.SerieTemporel.exception;

public class ExceptionNonAutoriseNonDroit extends Exception{
    public ExceptionNonAutoriseNonDroit(String message) {
        super(message);
    }
}
