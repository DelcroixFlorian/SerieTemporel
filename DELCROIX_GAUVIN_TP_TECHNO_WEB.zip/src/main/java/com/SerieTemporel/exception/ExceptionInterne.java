package com.SerieTemporel.exception;

public class ExceptionInterne extends Exception {
    public ExceptionInterne(String message) {
        super(message);
    }
}
