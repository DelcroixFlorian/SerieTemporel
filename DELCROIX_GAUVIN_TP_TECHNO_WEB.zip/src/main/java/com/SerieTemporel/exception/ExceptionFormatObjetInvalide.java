package com.SerieTemporel.exception;

public class ExceptionFormatObjetInvalide extends Exception {
    public ExceptionFormatObjetInvalide(String message) {
        super(message);
    }
}
