package com.SerieTemporel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerieTemporelApplicationTests {

	@Test
	void contextLoads() {
	}

}
